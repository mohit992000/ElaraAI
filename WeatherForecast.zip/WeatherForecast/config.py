API_KEY = "9a42afc28783490ba5861248250204"
BASE_URL = "http://api.weatherapi.com/v1/current.json"