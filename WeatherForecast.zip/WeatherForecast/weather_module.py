import requests
from config import API_KEY, BASE_URL


#using lib emoji
import emoji

WEATHER_EMOJIS = {
    "clear": ("Sunny", emoji.emojize(":sun:")),
    "sunny": ("Sunny", emoji.emojize(":sun_with_face:")),
    "partly cloudy": ("Partly Cloudy", emoji.emojize(":white_sun_behind_cloud:")),
    "cloudy": ("Cloudy", emoji.emojize(":cloud:")),
    "overcast": ("Overcast", emoji.emojize(":cloud:")),
    "mist": ("Mist", emoji.emojize(":fog:")),
    "fog": ("Foggy", emoji.emojize(":fog:")),
    "haze": ("Hazy", emoji.emojize(":fog:")),
    "light rain": ("Light Rain", emoji.emojize(":cloud_with_rain:")),
    "heavy rain": ("Heavy Rain", emoji.emojize(":cloud_with_rain:")),
    "moderate rain": ("Moderate Rain", emoji.emojize(":cloud_with_rain:")),
    "drizzle": ("Drizzle", emoji.emojize(":droplet:")),
    "snow": ("Snow", emoji.emojize(":snowflake:")),
    "light snow": ("Light Snow", emoji.emojize(":snowflake:")),
    "heavy snow": ("Heavy Snow", emoji.emojize(":snow_cloud:")),
    "thunderstorm": ("Thunderstorm", emoji.emojize(":cloud_with_lightning_and_rain:")),
    "windy": ("Windy", emoji.emojize(":dash:")),
    "blizzard": ("Blizzard", emoji.emojize(":cloud_with_snow:")),
    "ice pellets": ("Ice Pellets", emoji.emojize(":snowflake:")),
    "sleet": ("Sleet", emoji.emojize(":cloud_with_snow:")),
    "smoke": ("Smoky", emoji.emojize(":cloud:")),
    "sand": ("Sandy", emoji.emojize(":desert:")),
    "dust": ("Dusty", emoji.emojize(":cloud:")),
}




def fetch_weather_data(city_name: str) -> dict:
    """Fetches weather data from WeatherAPI and handles errors properly."""
    try:
        response = requests.get(f"{BASE_URL}?key={API_KEY}&q={city_name}")
        response.raise_for_status()  # Raises an HTTP error for non-200 responses
        return response.json()
    
    except requests.exceptions.HTTPError as http_err:
        if response.status_code == 400:
            return {"error": "Invalid city name. Please check the spelling and try again."}
        elif response.status_code == 401:
            return {"error": "Invalid API key. Please check your API key in config.py."}
        elif response.status_code == 403:
            return {"error": "Access denied. Your API plan may not allow this request."}
        elif response.status_code == 404:
            return {"error": "City not found. Please enter a valid location."}
        else:
            return {"error": f"HTTP error occurred: {http_err}"}

    except requests.exceptions.ConnectionError:
        return {"error": "No internet connection. Please check your network and try again."}
    
    except requests.exceptions.Timeout:
        return {"error": "The request timed out. Please try again later."}
    
    except requests.exceptions.RequestException as req_err:
        return {"error": f"Unexpected error: {req_err}"}




def get_condition_description(condition_text: str) -> str:
    condition_text = condition_text.lower()
    for key in WEATHER_EMOJIS:
        if key in condition_text:
            desc, emoji_icon = WEATHER_EMOJIS[key]
            return f"{emoji_icon} {desc}"
    return f"🌈 {condition_text.capitalize()}"  # fallback


def get_temp_emoji(temp: float) -> str:
    if temp <= -10:
        return "🥶"
    elif -10 < temp <= 0:
        return "❄️"
    elif 0 < temp <= 15:
        return "🧥"
    elif 15 < temp <= 25:
        return "🙂"
    elif 25 < temp <= 35:
        return "🥵"
    else:
        return "🔥"

def get_humidity_emoji(humidity: int) -> str:
    if humidity >= 80:
        return "💦"
    elif humidity >= 50:
        return "💧"
    else:
        return "🌵"

def get_wind_emoji(speed: float) -> str:
    if speed >= 40:
        return "🌪️"
    elif speed >= 20:
        return "🌬️"
    elif speed >= 10:
        return "🍃"
    else:
        return "🪁"

def parse_weather_data(data: dict) -> str:
    if "error" in data:
        return f"❌ Error: {data['error']}"

    try:
        location = data["location"]["name"]
        region = data["location"]["region"]
        country = data["location"]["country"]

        condition = data["current"]["condition"]["text"]
        temp = data["current"]["temp_c"]
        humidity = data["current"]["humidity"]
        wind_speed = data["current"]["wind_kph"]

        condition_with_emoji = get_condition_description(condition)
        temp_emoji = get_temp_emoji(temp)
        humidity_emoji = get_humidity_emoji(humidity)
        wind_emoji = get_wind_emoji(wind_speed)

        return f"""
📍 Location: {location}, {region}, {country}
{condition_with_emoji} Condition: {condition}
{temp_emoji} Temperature: {temp}°C
{humidity_emoji} Humidity: {humidity}%
{wind_emoji} Wind Speed: {wind_speed} km/h
        """
    except KeyError as e:
        return f"❌ Error: Missing data in API response ({e})"




def get_weather(city_name: str) -> str:
    """Returns formatted weather data for a given city."""
    weather_data = fetch_weather_data(city_name)
    return parse_weather_data(weather_data)
