import speech_recognition as sr
from weather_module import get_weather

def get_voice_input() -> str:
    """Captures city name using voice input."""
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("🎙️ Speak the city name...")
        try:
            audio = recognizer.listen(source, timeout=5)
            city = recognizer.recognize_google(audio)
            print(f"📍 Recognized city: {city}")
            return city
        except sr.UnknownValueError:
            print("⚠️ Sorry, I couldn't understand you.")
        except sr.RequestError:
            print("⚠️ Network error with voice recognition.")
        return None

if __name__ == "__main__":
    print("🔹 Choose input method:")
    print("1️⃣ Type the city name")
    print("2️⃣ Use voice input")

    choice = input("Enter choice (1 or 2): ")

    if choice == "2":
        city = get_voice_input()
    else:
        city = input("Enter city name: ")

    if city:
        print(get_weather(city))
    else:
        print("⚠️ No valid city input provided.")
11