
import os
import sys
from typing import Dict, Tuple, Union
import openai
from openai import OpenAI
import time
from prompt_formatter import format_prompt, generate_elara_response
from src.identity_manager import IdentityManager

class LLMConnector:
    def __init__(self):
        """Initialize the LLM connector with OpenAI API settings."""
        print("Initializing LLMConnector")
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.client = OpenAI(api_key=self.api_key) if self.api_key else None
        self.identity_manager = IdentityManager()
        self.max_retries = 3
        self.retry_delay = 1  # seconds
        self.supported_backends = {"openai": self._call_openai_api}

    def _format_openai_prompt(self, user_id: int, user_input: str) -> list[dict]:
        """Format the prompt for OpenAI API with system and user messages."""
        print("Formatting OpenAI prompt")
        formatted_prompt = format_prompt(user_id, user_input)
        system_prompt = formatted_prompt.split("[User Input]")[0].replace("[System Prompt]\n", "").strip()
        user_prompt = formatted_prompt.split("[User Input]\n")[1].strip()
        return [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]

    def _call_openai_api(self, messages: list[dict]) -> Tuple[str, str]:
        """Call OpenAI API and return raw and formatted responses."""
        print("Calling OpenAI API")
        if not self.client:
            raise ValueError("OpenAI client not initialized. API key missing.")
        for attempt in range(self.max_retries):
            try:
                response = self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=messages,
                    max_tokens=150,
                    temperature=0.7
                )
                raw_response = response.choices[0].message.content
                formatted_response = raw_response.strip()
                return raw_response, formatted_response
            except openai.OpenAIError as e:
                if attempt == self.max_retries - 1:
                    raise Exception(f"OpenAI API failed after {self.max_retries} attempts: {str(e)}")
                time.sleep(self.retry_delay)
        return "", "Error: No response after retries"

    def get_elara_response(self, user_id: int, user_input: str, simulate: bool = True, backend: str = "openai") -> Dict[str, str]:
        """
        Sends the formatted prompt to an LLM (real or simulated) and returns raw and formatted responses.
        """
        print(f"Getting Elara response for user_id={user_id}, simulate={simulate}")
        if not isinstance(user_id, int) or user_id < 10000 or user_id > 99999:
            raise ValueError("User ID must be a 5-digit integer")

        if not simulate:
            if backend not in self.supported_backends:
                raise ValueError(f"Unsupported backend: {backend}")
            if not self.client:
                raise ValueError("OpenAI client not initialized. API key missing.")

        try:
            if simulate:
                print("Using simulated response")
                formatted_response = generate_elara_response(user_id, user_input)
                return {"raw": formatted_response, "formatted": formatted_response}
            else:
                messages = self._format_openai_prompt(user_id, user_input)
                raw_response, formatted_response = self.supported_backends[backend](messages)
                return {"raw": raw_response, "formatted": formatted_response}
        except Exception as e:
            error_msg = f"Error: Failed to get response - {str(e)}"
            print(error_msg)
            return {"raw": error_msg, "formatted": error_msg}
