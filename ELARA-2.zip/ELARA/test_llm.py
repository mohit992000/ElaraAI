import os
import pytest
from llm_connector import LLMConnector
from src.identity_manager import IdentityManager

@pytest.fixture
def connector():
    """Initialize LLMConnector for testing."""
    return LLMConnector()

@pytest.fixture
def user_id():
    """Create a test user ID and profile."""
    im = IdentityManager()
    test_user_id = 12345
    test_profile = im.get_context(test_user_id)
    test_profile.update({
        "name": "Test User",
        "username": "testuser",
        "alignment": {"formality": "casual", "humor": "medium", "response_length": "concise"},
        "personality": "friend"
    })
    im.update_context(test_user_id, test_profile)
    return test_user_id

def test_simulated_response(connector, user_id):
    """Test simulated response generation."""
    response = connector.get_elara_response(user_id, "What's up?", simulate=True)
    assert "raw" in response
    assert "formatted" in response
    assert "Elara says" in response["formatted"]
    assert "friend" in response["formatted"].lower()

def test_invalid_user_id(connector):
    """Test response with invalid user ID."""
    with pytest.raises(ValueError, match="User ID must be a 5-digit integer"):
        connector.get_elara_response(123, "What's up?", simulate=True)

@pytest.mark.skipif(not os.getenv("OPENAI_API_KEY"), reason="No OpenAI API key provided")
def test_real_openai_response(connector, user_id):
    """Test real OpenAI API response."""
    response = connector.get_elara_response(user_id, "Tell me a joke", simulate=False)
    assert "raw" in response
    assert "formatted" in response
    assert response["formatted"] != ""
    assert "Error" not in response["formatted"]

def test_unsupported_backend(connector, user_id):
    """Test response with unsupported backend."""
    with pytest.raises(ValueError, match="Unsupported backend: claude"):
        connector.get_elara_response(user_id, "What's up?", simulate=False, backend="claude")

def test_missing_api_key_no_simulate(monkeypatch, connector, user_id):
    """Test behavior when API key is missing and simulate is False."""
    monkeypatch.setenv("OPENAI_API_KEY", "")
    with pytest.raises(ValueError, match="OpenAI client not initialized"):
        connector.get_elara_response(user_id, "What's up?", simulate=False)