from prompt_formatter import format_prompt
from llm_connector import LLMConnector
from prompt_formatter import format_prompt

def main():
    try:
        # Ask for a 5-digit user ID
        user_id_input = input("Enter a 5-digit user ID: ").strip()
        if not user_id_input.isdigit() or len(user_id_input) != 5:
            print("❌ User ID must be a 5-digit number.")
            return
        user_id = int(user_id_input)

        # Ask for the user's question
        user_input = input("Ask Elara something: ").strip()
        if not user_input:
            print("❌ Question cannot be empty.")
            return

        # Format and show the prompt
        result = format_prompt(user_id, user_input)
        print("\n🧠 Elara Prompt:\n")
        print(result)
        
        # Get response using LLMConnector
        print("Initializing LLMConnector")
        connector = LLMConnector()
        print("Calling get_elara_response")
        response = connector.get_elara_response(user_id, user_input, simulate=True)
        print("\n🧠 Elara Response:\n")
        print(response["formatted"])
    except Exception as e:
        print(f"⚠️ Error: {e}")

if __name__ == "__main__":
    main()
