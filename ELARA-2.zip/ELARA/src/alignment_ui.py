import tkinter as tk
from tkinter import messagebox, ttk
import json
import re
from identity_manager import IdentityManager

class AlignmentUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Elara Alignment Control")
        self.manager = IdentityManager()
        self.user_id = None
        self.goals = []
        self.username_to_id = {}

        # Main frame
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Search Section
        ttk.Label(self.main_frame, text="Search User by Username:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.username_search_var = tk.StringVar()
        self.username_search_combo = ttk.Combobox(self.main_frame, textvariable=self.username_search_var, state="readonly")
        self.username_search_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Search", command=self.search_user).grid(row=0, column=2, padx=5)

        # User ID
        ttk.Label(self.main_frame, text="User ID (5-digit integer):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.user_id_entry = ttk.Entry(self.main_frame)
        self.user_id_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)

        # Name
        ttk.Label(self.main_frame, text="Name:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk.Entry(self.main_frame)
        self.name_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)

        # Username
        ttk.Label(self.main_frame, text="Username (letters, numbers, special chars):").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.username_entry = ttk.Entry(self.main_frame)
        self.username_entry.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)

        # Set User button
        self.set_user_button = ttk.Button(self.main_frame, text="Set User", command=self.set_user)
        self.set_user_button.grid(row=1, column=2, rowspan=3, padx=5, sticky=tk.N)

        # Save button (initially hidden)
        self.save_button = ttk.Button(self.main_frame, text="Save", command=self.save_new_user)
        self.save_button.grid(row=4, column=0, columnspan=3, pady=5)
        self.save_button.grid_remove()

        # Goals Section
        ttk.Label(self.main_frame, text="Goals:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.goal_entry = ttk.Entry(self.main_frame)
        self.goal_entry.grid(row=5, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Add Goal", command=self.add_goal).grid(row=5, column=2, padx=5)

        # Goals Listbox
        self.goals_listbox = tk.Listbox(self.main_frame, height=3, width=30)
        self.goals_listbox.grid(row=6, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Remove Selected Goal", command=self.remove_goal).grid(row=6, column=2, padx=5)

        # Weather Units
        ttk.Label(self.main_frame, text="Weather Units:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.weather_units_var = tk.StringVar()
        self.weather_units_combo = ttk.Combobox(self.main_frame, textvariable=self.weather_units_var, 
                                              values=["Celsius", "Fahrenheit"], state="readonly")
        self.weather_units_combo.grid(row=7, column=1, sticky=(tk.W, tk.E), pady=5)
        self.weather_units_combo.set("Celsius")

        # Formality
        ttk.Label(self.main_frame, text="Formality:").grid(row=8, column=0, sticky=tk.W, pady=5)
        self.formality_var = tk.StringVar()
        self.formality_combo = ttk.Combobox(self.main_frame, textvariable=self.formality_var, 
                                          values=["casual", "neutral", "formal"], state="readonly")
        self.formality_combo.grid(row=8, column=1, sticky=(tk.W, tk.E), pady=5)
        self.formality_combo.set("casual")

        # Humor
        ttk.Label(self.main_frame, text="Humor Level:").grid(row=9, column=0, sticky=tk.W, pady=5)
        self.humor_var = tk.StringVar()
        self.humor_combo = ttk.Combobox(self.main_frame, textvariable=self.humor_var, 
                                      values=["none", "medium", "high"], state="readonly")
        self.humor_combo.grid(row=9, column=1, sticky=(tk.W, tk.E), pady=5)
        self.humor_combo.set("medium")

        # Response Length
        ttk.Label(self.main_frame, text="Response Length:").grid(row=10, column=0, sticky=tk.W, pady=5)
        self.response_length_var = tk.StringVar()
        self.response_length_combo = ttk.Combobox(self.main_frame, textvariable=self.response_length_var, 
                                               values=["concise", "detailed"], state="readonly")
        self.response_length_combo.grid(row=10, column=1, sticky=(tk.W, tk.E), pady=5)
        self.response_length_combo.set("concise")

        # Save Changes and Logout Buttons
        self.save_changes_button = ttk.Button(self.main_frame, text="Save Changes", command=self.save_changes)
        self.save_changes_button.grid(row=11, column=0, columnspan=2, pady=10)
        self.save_changes_button.grid_remove()

        self.logout_button = ttk.Button(self.main_frame, text="Logout", command=self.logout)
        self.logout_button.grid(row=11, column=2, pady=10)
        self.logout_button.grid_remove()

        # Show Profile Button
        ttk.Button(self.main_frame, text="Show Profile", command=self.show_profile).grid(row=12, column=0, columnspan=3, pady=5)

        # Profile display
        self.profile_text = tk.Text(self.main_frame, height=10, width=50)
        self.profile_text.grid(row=13, column=0, columnspan=3, pady=10)
        self.profile_text.config(state="disabled")

        # Populate usernames for search
        self.populate_usernames()

    def populate_usernames(self):
        self.username_to_id = self.manager.get_all_usernames()
        self.username_search_combo["values"] = list(self.username_to_id.keys())
        if self.username_to_id:
            self.username_search_var.set(list(self.username_to_id.keys())[0])
        else:
            self.username_search_var.set("")

    def search_user(self):
        username = self.username_search_var.get()
        if not username:
            messagebox.showerror("Error", "Please select a username to search")
            return
        self.user_id = self.username_to_id.get(username)
        if self.user_id is None:
            messagebox.showerror("Error", "User not found")
            return
        try:
            profile = self.manager.get_context(self.user_id)
            self.goals = profile.get("goals", [])
            self.goals_listbox.delete(0, tk.END)
            for goal in self.goals:
                self.goals_listbox.insert(tk.END, goal)
            self.weather_units_var.set(profile.get("preferences", {}).get("weather_units", "Celsius"))
            self.formality_var.set(profile.get("alignment", {}).get("formality", "casual"))
            self.humor_var.set(profile.get("alignment", {}).get("humor", "medium"))
            self.response_length_var.set(profile.get("alignment", {}).get("response_length", "concise"))
            self.user_id_entry.delete(0, tk.END)
            self.user_id_entry.insert(0, str(self.user_id))
            self.name_entry.delete(0, tk.END)
            self.name_entry.insert(0, profile.get("name", ""))
            self.username_entry.delete(0, tk.END)
            self.username_entry.insert(0, profile.get("username", ""))
            self.goal_entry.delete(0, tk.END)
            self.set_user_button.grid_remove()
            self.save_button.grid_remove()
            self.save_changes_button.grid()
            self.logout_button.grid()
            messagebox.showinfo("Success", f"Logged in as {username} (User ID: {self.user_id})")
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to load user: {str(e)}")

    def set_user(self):
        # Validate User ID
        user_id_str = self.user_id_entry.get().strip()
        if not user_id_str.isdigit() or len(user_id_str) != 5:
            messagebox.showerror("Error", "User ID must be a 5-digit integer")
            return
        user_id = int(user_id_str)

        # Validate Name
        name = self.name_entry.get().strip()
        if not name:
            messagebox.showerror("Error", "Please enter a valid Name")
            return

        # Validate Username
        username = self.username_entry.get().strip()
        if not username:
            messagebox.showerror("Error", "Please enter a valid Username")
            return
        if not re.match(r'^[a-zA-Z0-9_!@#$%^&*()-+=]+$', username):
            messagebox.showerror("Error", "Username can only contain letters, numbers, and special characters (_!@#$%^&*()-+=)")
            return

        # Check if username already exists
        existing_usernames = self.manager.get_all_usernames()
        if username in existing_usernames and existing_usernames[username] != user_id:
            messagebox.showerror("Error", "Username already exists. Please choose a different username.")
            return

        self.user_id = user_id
        # Initialize or update profile with name and username
        try:
            profile = self.manager.get_context(self.user_id)
            profile["name"] = name
            profile["username"] = username
            # Load existing goals and settings
            self.goals = profile.get("goals", [])
            self.goals_listbox.delete(0, tk.END)
            for goal in self.goals:
                self.goals_listbox.insert(tk.END, goal)
            self.weather_units_var.set(profile.get("preferences", {}).get("weather_units", "Celsius"))
            self.formality_var.set(profile.get("alignment", {}).get("formality", "casual"))
            self.humor_var.set(profile.get("alignment", {}).get("humor", "medium"))
            self.response_length_var.set(profile.get("alignment", {}).get("response_length", "concise"))
            self.set_user_button.grid_remove()
            self.save_button.grid()
            self.save_changes_button.grid()
            self.logout_button.grid()
            messagebox.showinfo("Success", f"User ID {self.user_id} set with Name: {name}, Username: {username}")
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to set user: {str(e)}")

    def save_new_user(self):
        if not self.user_id:
            messagebox.showerror("Error", "No user set to save")
            return
        try:
            profile = self.manager.get_context(self.user_id)
            profile["goals"] = self.goals
            profile["preferences"]["weather_units"] = self.weather_units_var.get()
            profile["alignment"]["formality"] = self.formality_var.get()
            profile["alignment"]["humor"] = self.humor_var.get()
            profile["alignment"]["response_length"] = self.response_length_var.get()
            self.manager.update_context(self.user_id, profile)
            messagebox.showinfo("Success", "New user saved successfully")
            self.logout()  # Clear fields and reset UI after saving
            self.populate_usernames()  # Refresh username dropdown
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save user: {str(e)}")

    def add_goal(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        goal = self.goal_entry.get().strip()
        if not goal:
            messagebox.showerror("Error", "Please enter a valid goal")
            return
        self.goals.append(goal)
        self.goals_listbox.insert(tk.END, goal)
        self.goal_entry.delete(0, tk.END)
        # Update profile with new goals
        try:
            profile = self.manager.get_context(self.user_id)
            profile["goals"] = self.goals
            self.manager.update_context(self.user_id, profile)
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add goal: {str(e)}")

    def remove_goal(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        selection = self.goals_listbox.curselection()
        if not selection:
            messagebox.showerror("Error", "Please select a goal to remove")
            return
        index = selection[0]
        self.goals.pop(index)
        self.goals_listbox.delete(index)
        # Update profile with updated goals
        try:
            profile = self.manager.get_context(self.user_id)
            profile["goals"] = self.goals
            self.manager.update_context(self.user_id, profile)
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to remove goal: {str(e)}")

    def save_changes(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        updates = {
            "preferences": {
                "weather_units": self.weather_units_var.get(),
                "news_topic": "technology"
            },
            "alignment": {
                "formality": self.formality_var.get(),
                "humor": self.humor_var.get(),
                "response_length": self.response_length_var.get()
            }
        }
        try:
            self.manager.update_context(self.user_id, updates)
            messagebox.showinfo("Success", "Profile updated successfully")
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to update profile: {str(e)}")

    def logout(self):
        self.user_id = None
        self.goals = []
        self.user_id_entry.delete(0, tk.END)
        self.name_entry.delete(0, tk.END)
        self.username_entry.delete(0, tk.END)
        self.goal_entry.delete(0, tk.END)
        self.goals_listbox.delete(0, tk.END)
        self.weather_units_var.set("Celsius")
        self.formality_var.set("casual")
        self.humor_var.set("medium")
        self.response_length_var.set("concise")
        self.profile_text.config(state="normal")
        self.profile_text.delete("1.0", tk.END)
        self.profile_text.config(state="disabled")
        self.set_user_button.grid()
        self.save_button.grid_remove()
        self.save_changes_button.grid_remove()
        self.logout_button.grid_remove()
        messagebox.showinfo("Success", "Logged out successfully")

    def show_profile(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        self.update_profile_display()

    def update_profile_display(self):
        if not self.user_id:
            return
        profile = self.manager.get_context(self.user_id)
        self.profile_text.config(state="normal")
        self.profile_text.delete("1.0", tk.END)
        self.profile_text.insert(tk.END, json.dumps(profile, indent=2))
        self.profile_text.config(state="disabled")

if __name__ == "__main__":
    root = tk.Tk()
    app = AlignmentUI(root)
    root.mainloop()