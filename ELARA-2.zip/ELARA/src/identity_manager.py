import json
import os
from pathlib import Path
from cryptography.fernet import Fernet
import logging

# Setup logging
logging.basicConfig(filename='logs/profile_updates.log', level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

class IdentityManager:
    def __init__(self, profiles_dir="data/profiles", key_file="config/secret.key"):
        self.profiles_dir = Path(profiles_dir)
        self.profiles_dir.mkdir(exist_ok=True, parents=True)
        self.key_file = Path(key_file)
        self.key_file.parent.mkdir(exist_ok=True)
        self.cipher = self._load_or_generate_key()
        self.default_profile = {
            "user_id": 0,
            "name": "",
            "username": "",
            "tone": "casual",
            "goals": [],
            "preferences": {
                "weather_units": "Celsius",
                "news_topic": "technology"
            },
            "alignment": {
                "formality": "casual",
                "humor": "medium",
                "response_length": "concise"
            }
        }

    def _load_or_generate_key(self):
        if self.key_file.exists():
            with open(self.key_file, 'rb') as f:
                key = f.read()
        else:
            key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(key)
        return Fernet(key)

    def _get_profile_path(self, user_id: int) -> Path:
        if not isinstance(user_id, int) or user_id < 10000 or user_id > 99999:
            raise ValueError("User ID must be a 5-digit integer")
        return self.profiles_dir / f"{user_id}.json"

    def get_context(self, user_id: int) -> dict:
        profile_path = self._get_profile_path(user_id)
        try:
            if not profile_path.exists():
                profile = self.default_profile.copy()
                profile["user_id"] = user_id
                self.update_context(user_id, profile)
                return profile
            with open(profile_path, 'rb') as f:
                encrypted_data = f.read()
            decrypted_data = self.cipher.decrypt(encrypted_data)
            return json.loads(decrypted_data)
        except Exception as e:
            logging.error(f"Error loading profile for {user_id}: {str(e)}")
            return self.default_profile.copy()

    def update_context(self, user_id: int, updates: dict) -> None:
        profile_path = self._get_profile_path(user_id)
        current_profile = self.get_context(user_id)
        current_profile.update(updates)
        try:
            encrypted_data = self.cipher.encrypt(json.dumps(current_profile).encode())
            with open(profile_path, 'wb') as f:
                f.write(encrypted_data)
            logging.info(f"Updated profile for {user_id}: {updates}")
        except Exception as e:
            logging.error(f"Error updating profile for {user_id}: {str(e)}")
            raise

    def get_all_usernames(self) -> dict:
        usernames = {}
        for profile_file in self.profiles_dir.glob("*.json"):
            user_id = int(profile_file.stem)
            try:
                profile = self.get_context(user_id)
                username = profile.get("username", "")
                if username:
                    usernames[username] = user_id
            except Exception as e:
                logging.error(f"Error reading profile {user_id}: {str(e)}")
        return usernames