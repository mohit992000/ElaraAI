from elara_core import run_elara_conversation

def main():
    try:
        # Ask for a 5-digit user ID
        user_id_input = input("Enter a 5-digit user ID: ").strip()
        if not user_id_input.isdigit() or len(user_id_input) != 5:
            print("❌ User ID must be a 5-digit number.")
            return
        user_id = int(user_id_input)

        # Ask for the user's question
        user_input = input("Ask Elara something: ").strip()
        if not user_input:
            print("❌ Question cannot be empty.")
            return

        # Run conversation and show result
        result = run_elara_conversation(user_id, user_input)
        print("\n🧠 Elara Conversation Result:\n")
        print(result)

    except Exception as e:
        print(f"⚠️ Error: {e}")

if __name__ == "__main__":
    main()