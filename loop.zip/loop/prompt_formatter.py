from identity_manager import IdentityManager

identity_manager = IdentityManager()

def format_prompt(user_id: int, user_input: str) -> str:
    """
    Returns a prompt that includes tone, humor, and length settings, plus goals and metadata.
    """
    profile = identity_manager.get_context(user_id)
    alignment = profile.get("alignment", {})
    formality = alignment.get("formality", "neutral")
    humor = alignment.get("humor", "none")
    response_length = alignment.get("response_length", "concise")
    goals = profile.get("goals", [])
    personality = profile.get("personality", "default")

    goal_clause = f" Keep in mind the user's goals: {', '.join(goals)}." if goals else ""
    metadata = f"[Tags: markdown, personality={personality}]"
    tone_description = f"in a {formality} tone"
    humor_description = " with a touch of humor" if humor != "none" else ""
    length_instruction = f"Keep your answer {response_length}."

    role_prefix = {
        "coach": "You are Elara, a motivating coach and assistant.",
        "friend": "You are Elara, a friendly and supportive assistant.",
        "expert": "You are Elara, a precise and knowledgeable expert assistant."
    }.get(personality, "You are Elara, a helpful assistant.")

    system_prompt = (
        f"{metadata}\n{role_prefix} Respond {tone_description}{humor_description}. "
        f"{length_instruction}{goal_clause}"
    )

    return f"[System Prompt]\n{system_prompt}\n\n[User Input]\n{user_input}"


from session_logger import save_response

def generate_elara_response(user_id: int, user_input: str) -> str:
    profile = identity_manager.get_context(user_id)
    personality = profile.get("personality", "default")
    humor = profile.get("alignment", {}).get("humor", "none")

    user_input_lower = user_input.lower()

    if "eat" in user_input_lower:
        base_response = "Feeling hungry? 🍕 How about some tacos, pasta, or even a good ol' grilled cheese?"
    elif "bored" in user_input_lower:
        base_response = "Boredom detected! Try dancing, drawing, or doomscrolling (responsibly)."
    else:
        base_response = {
            "coach": f"Alright, let's channel that energy! 💪 {user_input.capitalize()}? You’re capable of way more — now go crush that next goal!",
            "friend": f"Aww, feeling something? Let’s put on your favorite tunes or go do something you love. ✨",
            "expert": f"As an expert, I’d recommend breaking this down into steps and tackling the highest priority item first.",
            "default": f"Sure! Here's something that might help: Try switching tasks or taking a mindful break. Let me know what you're in the mood for."
        }.get(personality, "default")

    markdown_response = f"### Elara says:\n\n{base_response}\n\n---\n**Tagged as:** `{personality}`"
    return markdown_response



 

