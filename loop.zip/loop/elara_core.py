from prompt_formatter import format_prompt, generate_elara_response
from identity_manager import IdentityManager
import json
from datetime import datetime
from collections import Counter
import os

class SessionLogger:
    def __init__(self, log_file: str = "data/elara_session_log.json"):
        self.log_file = log_file
        self.tag_counter = Counter()
        try:
            with open(self.log_file, 'r') as f:
                self.log = json.load(f)
                # Restore existing tag counts
                for entry in self.log:
                    tag = entry.get("tag")
                    if tag:
                        self.tag_counter[tag] += 1
        except FileNotFoundError:
            self.log = []

    def save_to_log(self, user_id: int, system_prompt: str, user_input: str, response: str, tag: str):
        timestamp = datetime.now().isoformat()
        interaction = {
            "user_id": user_id,
            "timestamp": timestamp,
            "system_prompt": system_prompt,
            "user_input": user_input,
            "response": response,
            "tag": tag
        }
        self.log.append(interaction)
        self.tag_counter[tag] += 1
        with open(self.log_file, 'w') as f:
            json.dump(self.log, f, indent=4)

    def get_tag_stats(self) -> dict:
        return dict(self.tag_counter)

def run_elara_conversation(user_id: int, user_input: str) -> str:
    identity = IdentityManager()
    logger = SessionLogger()

    user_context = identity.get_context(user_id)

    # Format prompt and extract system prompt portion
    full_prompt = format_prompt(user_id, user_input)
    system_prompt = full_prompt.split("[User Input]")[0].replace("[System Prompt]\n", "").strip()

    # Generate response and extract tag
    response = generate_elara_response(user_id, user_input)
    try:
        tag = response.split("**Tagged as:** `")[1].split("`")[0].strip()
    except IndexError:
        tag = "unknown"

    # Save context and log
    
    identity.update_context(user_id, {
        "history": user_context.get("history", []) + [{
           "input": user_input,
           "response": response,
           "tag": tag
        }]
     })

# 🔁 Reload updated memory for recent display
    user_context = identity.get_context(user_id)
    history = user_context.get("history", [])[-3:]

    # Build output
    output = f"[System Prompt]\n{system_prompt}\n\n[User Input]\n{user_input}\n\n[Elara's Response]\n{response}\n\n*Tagged as:* {tag}"

    # Bonus: add tag stats
    stats = logger.get_tag_stats()
    output += "\n\n[Tag Stats]"
    for k, v in stats.items():
      output += f"\n- {k}: {v} times"

    history = user_context.get("history", [])[-3:]  # Show last 3 entries
    output += "\n\n[Recent Memory]"
    for h in history:
    # Attempt to get first non-empty line after "### Elara says:"
       lines = h['response'].splitlines()
       response_summary = next((line for line in lines if line.strip() and not line.startswith("###")), "[no reply]")
       output += f"\n• You said: {h['input']} → Elara replied: {response_summary}"




    return output
