import json
import os
from datetime import datetime
from collections import defaultdict

LOG_FILE = "session_log.json"
STATS_FILE = "tag_stats.json"

def save_response(user_id, user_input, elara_response, personality):
    log_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "user_id": user_id,
        "input": user_input,
        "response": elara_response,
        "personality": personality
    }

    # Save to session log
    if not os.path.exists(LOG_FILE):
        with open(LOG_FILE, "w") as f:
            json.dump([], f)

    with open(LOG_FILE, "r+") as f:
        data = json.load(f)
        data.append(log_entry)
        f.seek(0)
        json.dump(data, f, indent=2)

    # Save or update tag stats
    if os.path.exists(STATS_FILE):
        with open(STATS_FILE, "r") as f:
            try:
                stats = json.load(f)
            except json.JSONDecodeError:
                stats = {}
    else:
        stats = {}

    stats[personality] = stats.get(personality, 0) + 1

    with open(STATS_FILE, "w") as f:
        json.dump(stats, f, indent=2)
