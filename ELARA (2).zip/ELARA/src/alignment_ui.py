import tkinter as tk
from tkinter import messagebox, ttk
import json
import re
from identity_manager import IdentityManager

class AlignmentUI:
    def __init__(self, root):
        self.root = root
        self.root.title("Elara Alignment Control")
        self.manager = IdentityManager()
        self.user_id = None
        self.goals = []
        self.username_to_id = {}

        # Main frame
        self.main_frame = ttk.Frame(self.root, padding="10")
        self.main_frame.grid(row=0, column=0, sticky=(tk.W, tk.E, tk.N, tk.S))

        # Search Section
        ttk.Label(self.main_frame, text="Search User by Username:").grid(row=0, column=0, sticky=tk.W, pady=5)
        self.username_search_var = tk.StringVar()
        self.username_search_combo = ttk.Combobox(self.main_frame, textvariable=self.username_search_var, state="readonly")
        self.username_search_combo.grid(row=0, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Search", command=self.search_user).grid(row=0, column=2, padx=5)

        # User ID
        ttk.Label(self.main_frame, text="User ID (5-digit integer):").grid(row=1, column=0, sticky=tk.W, pady=5)
        self.user_id_entry = ttk.Entry(self.main_frame)
        self.user_id_entry.grid(row=1, column=1, sticky=(tk.W, tk.E), pady=5)

        # Name
        ttk.Label(self.main_frame, text="Name:").grid(row=2, column=0, sticky=tk.W, pady=5)
        self.name_entry = ttk.Entry(self.main_frame)
        self.name_entry.grid(row=2, column=1, sticky=(tk.W, tk.E), pady=5)

        # Username
        ttk.Label(self.main_frame, text="Username (letters, numbers, special chars):").grid(row=3, column=0, sticky=tk.W, pady=5)
        self.username_entry = ttk.Entry(self.main_frame)
        self.username_entry.grid(row=3, column=1, sticky=(tk.W, tk.E), pady=5)

        # Set User button
        self.set_user_button = ttk.Button(self.main_frame, text="Set User", command=self.set_user)
        self.set_user_button.grid(row=1, column=2, rowspan=3, padx=5, sticky=tk.N)

        # Save button (initially hidden)
        self.save_button = ttk.Button(self.main_frame, text="Save", command=self.save_new_user)
        self.save_button.grid(row=4, column=0, columnspan=3, pady=5)
        self.save_button.grid_remove()

        # Goals Section
        ttk.Label(self.main_frame, text="Goals:").grid(row=5, column=0, sticky=tk.W, pady=5)
        self.goal_entry = ttk.Entry(self.main_frame)
        self.goal_entry.grid(row=5, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Add Goal", command=self.add_goal).grid(row=5, column=2, padx=5)

        # Goals Listbox
        self.goals_listbox = tk.Listbox(self.main_frame, height=3, width=30)
        self.goals_listbox.grid(row=6, column=1, sticky=(tk.W, tk.E), pady=5)
        ttk.Button(self.main_frame, text="Remove Selected Goal", command=self.remove_goal).grid(row=6, column=2, padx=5)

        # Weather Units
        ttk.Label(self.main_frame, text="Weather Units:").grid(row=7, column=0, sticky=tk.W, pady=5)
        self.weather_units_var = tk.StringVar()
        self.weather_units_combo = ttk.Combobox(self.main_frame, textvariable=self.weather_units_var,
                                                values=["Celsius", "Fahrenheit"], state="readonly")
        self.weather_units_combo.grid(row=7, column=1, sticky=(tk.W, tk.E), pady=5)
        self.weather_units_combo.set("Celsius")

        # Formality
        ttk.Label(self.main_frame, text="Formality:").grid(row=8, column=0, sticky=tk.W, pady=5)
        self.formality_var = tk.StringVar()
        self.formality_combo = ttk.Combobox(self.main_frame, textvariable=self.formality_var,
                                            values=["casual", "neutral", "formal"], state="readonly")
        self.formality_combo.grid(row=8, column=1, sticky=(tk.W, tk.E), pady=5)
        self.formality_combo.set("casual")

        # Humor
        ttk.Label(self.main_frame, text="Humor Level:").grid(row=9, column=0, sticky=tk.W, pady=5)
        self.humor_var = tk.StringVar()
        self.humor_combo = ttk.Combobox(self.main_frame, textvariable=self.humor_var,
                                        values=["none", "medium", "high"], state="readonly")
        self.humor_combo.grid(row=9, column=1, sticky=(tk.W, tk.E), pady=5)
        self.humor_combo.set("medium")

        # Response Length
        ttk.Label(self.main_frame, text="Response Length:").grid(row=10, column=0, sticky=tk.W, pady=5)
        self.response_length_var = tk.StringVar()
        self.response_length_combo = ttk.Combobox(self.main_frame, textvariable=self.response_length_var,
                                                  values=["concise", "detailed"], state="readonly")
        self.response_length_combo.grid(row=10, column=1, sticky=(tk.W, tk.E), pady=5)
        self.response_length_combo.set("concise")

        # Personality
        ttk.Label(self.main_frame, text="Personality:").grid(row=11, column=0, sticky=tk.W, pady=5)
        self.personality_var = tk.StringVar()
        self.personality_combo = ttk.Combobox(self.main_frame, textvariable=self.personality_var,
                                              values=["default", "coach", "friend", "expert"], state="readonly")
        self.personality_combo.grid(row=11, column=1, sticky=(tk.W, tk.E), pady=5)
        self.personality_combo.set("default")

        # Save Changes and Logout Buttons
        self.save_changes_button = ttk.Button(self.main_frame, text="Save Changes", command=self.save_changes)
        self.save_changes_button.grid(row=12, column=0, columnspan=2, pady=10)
        self.save_changes_button.grid_remove()

        self.logout_button = ttk.Button(self.main_frame, text="Logout", command=self.logout)
        self.logout_button.grid(row=12, column=2, pady=10)
        self.logout_button.grid_remove()

        # Show Profile Button
        ttk.Button(self.main_frame, text="Show Profile", command=self.show_profile).grid(row=13, column=0, columnspan=3, pady=5)

        # Profile display
        self.profile_text = tk.Text(self.main_frame, height=10, width=50)
        self.profile_text.grid(row=14, column=0, columnspan=3, pady=10)
        self.profile_text.config(state="disabled")

        # Populate usernames for search
        self.populate_usernames()

    def add_goal(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        goal = self.goal_entry.get().strip()
        if not goal:
            messagebox.showerror("Error", "Please enter a valid goal")
            return
        self.goals.append(goal)
        self.goals_listbox.insert(tk.END, goal)
        self.goal_entry.delete(0, tk.END)
        try:
            profile = self.manager.get_context(self.user_id)
            profile["goals"] = self.goals
            self.manager.update_context(self.user_id, profile)
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to add goal: {str(e)}")

    def remove_goal(self):
        if not self.user_id:
            messagebox.showerror("Error", "Please set User ID first")
            return
        selection = self.goals_listbox.curselection()
        if not selection:
            messagebox.showerror("Error", "Please select a goal to remove")
            return
        index = selection[0]
        self.goals.pop(index)
        self.goals_listbox.delete(index)
        try:
            profile = self.manager.get_context(self.user_id)
            profile["goals"] = self.goals
            self.manager.update_context(self.user_id, profile)
            self.update_profile_display()
        except Exception as e:
            messagebox.showerror("Error", f"Failed to remove goal: {str(e)}")
