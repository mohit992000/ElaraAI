import requests
import html # To convert HTML entities (like &#8217;) into normal characters


# Emojis for topics
TOPIC_EMOJIS = {
    "health": "💉",
    "technology": "💻",
    "finance": "💰",
    "sports": "🏅",
    "science": "🔬",
    "politics": "🏛️",
    "business": "📈",
    "entertainment": "🎬",
    "world": "🌍"
}

# API key mediastack
API_KEY = "504d32021c9c4577cf6c83445721d405"
BASE_URL = "http://api.mediastack.com/v1/news"



def get_news(topic):
    emoji = TOPIC_EMOJIS.get(topic.lower(), "📰")
    params = {
        "access_key": API_KEY, # API authentication key
        "keywords": topic, # The topic you want news about
        "languages": "en", # Only English news
        "limit": 10  # Get more and filter later
    }
# Make a GET request to the API
    response = requests.get(BASE_URL, params=params)

    # Convert the response JSON into a Python dictionary
    data = response.json()

    # Get the list of news articles from the data
    articles = data.get("data", [])

    # If no articles found, return a message
    if not articles:
        return f"⚠️ No news found for '{topic}'."

    # Get the emoji for the topic, or use default 📰
    emoji = TOPIC_EMOJIS.get(topic.lower(), "📰")

    # Prepare the result string
    result = f"{emoji} Top News on '{topic}':\n\n"

    seen_titles = set()  # To avoid duplicate articles
    count = 1            # Article numbering

    # Loop through the list of articles
    for article in articles:
        # Clean up any HTML entities in the title/description
        title = html.unescape(article['title'])
        description = html.unescape(article['description'])

        # Skip if this article title was already shown
        if title in seen_titles:
            continue
        seen_titles.add(title)

        # Add the article info to the result
        result += f"{count}. Title: {title}\n"
        result += f"   Description: {description}\n"
        result += f"   URL: {article['url']}\n\n"

        count += 1

        # Stop after showing top 3 unique articles
        if count > 3:
            break

    return result