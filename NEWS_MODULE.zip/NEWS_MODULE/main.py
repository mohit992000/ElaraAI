from news_module import get_news

if __name__ == "__main__":
    topic = input("Enter a topic (e.g., health, technology): ")
    print(get_news(topic))
